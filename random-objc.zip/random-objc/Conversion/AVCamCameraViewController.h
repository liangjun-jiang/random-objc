/*
L. Jiang

Abstract:
View controller for camera interface.
*/

@import UIKit;

@interface AVCamCameraViewController : UIViewController
@property (strong, nonatomic) id dataObject;
@end
