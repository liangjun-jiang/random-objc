//
//  Sample.m
//  Conversion
//
//  Created by l.jiang on 10/30/18.
//  Copyright © 2018 U. of Arizona. All rights reserved.
//

#import "Sample.h"

@implementation Sample
@dynamic videoFile;

+ (NSString *)parseClassName {
    return @"Sample";
}
@end
